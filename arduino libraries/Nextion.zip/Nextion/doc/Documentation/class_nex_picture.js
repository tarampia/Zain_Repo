var class_nex_picture =
[
    [ "NexPicture", "class_nex_picture.html#aa6096defacd933e8bff5283c83200459", null ],
    [ "getPic", "class_nex_picture.html#a11bd68ef9fe1d03d9e0d02ef1c7527e9", null ],
    [ "setPic", "class_nex_picture.html#ab1c6adff615d48261ce10c2095859abd", null ]
];