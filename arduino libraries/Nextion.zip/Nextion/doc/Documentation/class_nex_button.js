var class_nex_button =
[
    [ "NexButton", "class_nex_button.html#a57d346614059bac40aff955a0dc9d76a", null ],
    [ "getText", "class_nex_button.html#a5ba1f74aa94b41b98172e42583ee13d6", null ],
    [ "setText", "class_nex_button.html#a649dafc5afb1dc7f1fc1bde1e6270290", null ]
];